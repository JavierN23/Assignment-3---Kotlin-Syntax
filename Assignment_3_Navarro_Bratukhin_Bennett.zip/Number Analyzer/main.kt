fun main() {

    var divisibleBy3Numbers = ""
    var divisibleBy3Sum = 0
    var evenCount = 0
    var oddCount = 0

    println ("All numbers:")

    for (numbers in 1..30) {
        print("$numbers ")
        if (numbers % 3 == 0) {
            divisibleBy3Sum += numbers
            divisibleBy3Numbers += "$numbers "
        }
        if (numbers % 2 == 0) {
            evenCount++
        } else {
            oddCount++
        }
    }


    println()
    println("\nNumbers divisible by 3:")
    println(divisibleBy3Numbers)
    println("\nSum of numbers divisible by 3: $divisibleBy3Sum")
    println("Even numbers: $evenCount")
    println("Odd numbers: $oddCount")

}