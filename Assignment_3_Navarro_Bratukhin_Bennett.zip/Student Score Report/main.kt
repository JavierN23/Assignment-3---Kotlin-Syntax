fun main() {
    val scores = listOf(95, 82, 67, 74, 58, 88)
    
    var total = 0
    
    var passingCount = 0
    var failingCount = 0
    
    for (score in scores) {
        total += score
        
        val classification = when (score) {
            in 90..100 -> "Excellent"
            in 80..89 -> "Good"
            in 70..79 -> "Satisfactory"
            in 60..69 -> "Needs Improvement"
            else -> "Fail"
        }
        println("Classification of score $score: $classification")
        
        if (score >= 60) {
            passingCount++
        } else {
            failingCount++
        }
    }
    val average = total.toDouble() / scores.size

    println("\nPassing scores: $passingCount")
    println("Failing scores: $failingCount")
    println("Average score: ${"%.1f".format(average)}")
}